import javax.swing.*;

public class Main {

    public static void main(String[] args)
    {
        System.out.println("Histogramas");
        JFrame window = new Ventana();
        window.setVisible(true);
    }
}
