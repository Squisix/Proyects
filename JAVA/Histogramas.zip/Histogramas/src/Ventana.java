import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.InputEvent;
import java.awt.event.KeyEvent;

public class Ventana extends JFrame {
    private JPanel panelRaiz;
    private JPanel controlPanel;
    private JButton cambiarColorButton;
    private JButton abrirArchivoButton;
    private JTextField textColor;
    private final PintaPanel pintaPanel;

    public Ventana()
    {
        super("Histogramas");

        JMenuBar barraMenu = new JMenuBar();
        JMenu colorMenu = new JMenu("Color");
        JMenu archivoMenu = new JMenu("Archivo");
        JMenuItem cambiaColorItem = new JMenuItem("Cambia color");
        cambiaColorItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_C, ActionEvent.ALT_MASK));
        cambiaColorItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                cambiaColor();
            }
        });
        JMenuItem salirItem = new JMenuItem("Salir");
        salirItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_Q, ActionEvent.ALT_MASK));
        salirItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                System.exit(0);
            }
        });
        JMenuItem abrirArchivoItem = new JMenuItem("Abrir archivo", KeyEvent.VK_F);
        abrirArchivoItem.setIcon(new ImageIcon("open-icon-16.png"));
        abrirArchivoItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_A, ActionEvent.ALT_MASK));
        abrirArchivoItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                abreArchivo();
            }
        });
        archivoMenu.add(abrirArchivoItem);
        archivoMenu.add(new JSeparator());
        archivoMenu.add(salirItem);
        colorMenu.add(cambiaColorItem);
        barraMenu.add(archivoMenu);
        barraMenu.add(colorMenu);
        setJMenuBar(barraMenu);

        setLayout(new BorderLayout());
        add(panelRaiz, BorderLayout.WEST);
        pintaPanel = new PintaPanel();
        add(pintaPanel, BorderLayout.CENTER);
        setSize(800, 400);
        setLocation(200, 50);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        cambiarColorButton.addActionListener(new ActionListener() {
            /**
             * Invoked when an action occurs.
             *
             * @param e the event to be processed
             */
            @Override
            public void actionPerformed(ActionEvent e)
            {
                cambiaColor();
            }
        });

        abrirArchivoButton.addActionListener(new ActionListener() {
            /**
             * Invoked when an action occurs.
             *
             * @param e the event to be processed
             */
            @Override
            public void actionPerformed(ActionEvent e)
            {
                abreArchivo();
            }
        });
    }

    private void cambiaColor()
    {
        Color color = JColorChooser.showDialog(null,
                "Seleccional color", pintaPanel.leeColor());
        if (color != null) {
            pintaPanel.cambiaColor(color);
            textColor.setBackground(color);
            textColor.setText(color.getRed() + "/" + color.getGreen() + "/" + color.getBlue());
        }
    }

    private void abreArchivo()
    {
        JFileChooser chooser = new JFileChooser("/Users/hvilla/Development/IdeaProjects/Histogramas");
        FileNameExtensionFilter filter = new FileNameExtensionFilter(
                "dat y txt", "dat", "txt");
        chooser.setFileFilter(filter);
        int valor = chooser.showOpenDialog(null);
        if (valor == JFileChooser.APPROVE_OPTION) {
            pintaPanel.cambiaDatos(chooser.getSelectedFile().getAbsolutePath());
        }
    }
}
