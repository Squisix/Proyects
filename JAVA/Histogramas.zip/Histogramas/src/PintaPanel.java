import javax.swing.*;
import java.awt.*;
import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;

public class PintaPanel extends JPanel {
    /*
    private String[] etiquetas = {"Ene", "Feb", "Mar", "Abr", "May", "Jun",
            "Jul", "Ago", "Sep", "Oct", "Nov", "Dic"};
    private double[] valores = {10000, 14400, 25800, 21000, 22500, 14820,
    19000, 7400, 19800, 21000, 29500, 20000};
     */
    private final ArrayList<String> etiquetas = new ArrayList<>();
    private final ArrayList<Double> valores = new ArrayList<>();
    private Color colorActual = Color.red;
    private int maxX;
    private double maxY;

    public PintaPanel()
    {
        super();
    }

    public Color leeColor()
    {
        return colorActual;
    }

    public void cambiaColor(Color color)
    {
        colorActual = color;
        repaint();
    }

    public void cambiaDatos(String archivo)
    {
        etiquetas.clear();
        valores.clear();

        try {
            BufferedReader handle = new BufferedReader(new FileReader(archivo));

            maxX = 0;
            maxY = Double.NEGATIVE_INFINITY;
            String linea;
            while ((linea = handle.readLine()) != null) {
                String[] datos = linea.trim().split("\\s+");
                //System.out.println(datos[0] + " " + datos[1]);
                etiquetas.add(datos[0]);
                double y = Double.parseDouble(datos[1]);
                if (y > maxY) {
                    maxY = y;
                }
                valores.add(y);
                maxX++;
            }

            repaint();

            handle.close();
        }
        catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error",
                    e.getMessage(), JOptionPane.ERROR_MESSAGE);
        }

        System.out.println("maxX: " + maxX + ", maxY: " + maxY);
    }

    public void paint(Graphics g)
    {
        Graphics2D g2 = (Graphics2D) g;
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        if (maxX == 0) {
            return;
        }

        int ancho = getWidth();
        int alto = getHeight();
        System.out.println("ancho: " + ancho + ", alto: " + alto);

        // Limpiar la pantalla
        g2.setColor(getBackground());
        g2.fillRect(0, 0, ancho, alto);

        // Histograma
        g2.setColor(colorActual);
        Transforma transforma = new Transforma(-2, -maxY / 10, maxX + 1, maxY * 1.2,
                0, 0, ancho, alto);

        for (int i = 0; i < valores.size(); i++) {
            Point p1 = transforma.proyectaw2v(i, valores.get(i));
            Point p2 = transforma.proyectaw2v(i + 1, 0);
            g2.fillRect(p1.x, p1.y, p2.x - p1.x, p2.y - p1.y);
        }

        // Ejes
        g2.setColor(Color.black);
        g2.setStroke(new BasicStroke(2));
        // Eje X
        Point p = transforma.proyectaw2v(0, 0);
        Point q = transforma.proyectaw2v(maxX + 1, 0);
        g2.drawLine(p.x, p.y, q.x, q.y);
        // Eje Y
        q = transforma.proyectaw2v(0, maxY * 1.2);
        g2.drawLine(p.x, p.y, q.x, q.y);

        // Etiquetas
        g2.setFont(new Font("Helvetica", Font.PLAIN, 20));
        for (int i = 0; i < etiquetas.size(); i++) {
            p = transforma.proyectaw2v(i + 0.2, -maxY / 15);
            g2.drawString(etiquetas.get(i), p.x, p.y);
        }

        // Valores
        g2.setFont(new Font("Helvetica", Font.BOLD, 10));
        for (int i = 0; i < valores.size(); i++) {
            p = transforma.proyectaw2v(i, valores.get(i) + valores.get(i) / 10);
            g2.drawString(valores.get(i) + "", p.x, p.y);
        }
    }
}
